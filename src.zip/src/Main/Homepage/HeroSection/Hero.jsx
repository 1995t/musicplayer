import './Hero.css'
import React, { useState } from 'react';
import axios from 'axios';

export const Hero = () => {
    const [playlist,setplaylist] = useState({});
    const getAlbumArt = async ()=>
        {
            const {data} =await axios.get('https://saavn.dev/api/search/playlists?query=Indie');
            setplaylist(data);
            console.log(playlist); 
        }
       
return (
    <>
    <div>
        <div >



        </div>
    </div>
    </>
)
}
