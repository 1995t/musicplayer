import './Navmenu.css';
import React from 'react'

export const Navmenu = () => {
  return (
    <>
    <div>
        <ul className='listmenu'>
            <li>All</li>
            <li>Trending Now</li>
            <li>Old Songs</li>
            <li>New Songs</li>
            <li>Moods & Genre</li>
            <li>Top Albums</li>
            <li>Top Artists</li>
            <li>Top Playlists</li>
            <li>Podcast</li>
        </ul>
        <div>
            <ul>
                li*
            </ul>
        </div>
    </div>
    </>
  )
}
