import './App.css';
import { Hero } from './Main/Homepage/HeroSection/Hero';
import { Navbar } from './Main/Homepage/Nav/Navbar';
import { Navmenu } from './Main/Homepage/Navmenu/Navmenu';

function App() {
  return (
    <>
    <Navbar/>
    <Navmenu/>
    <Hero/>
    </>
  );
}

export default App;
